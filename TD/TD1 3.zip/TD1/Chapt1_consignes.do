/*********************************************************************************************


		Author:  Esther Delesalle

	------------------------------------------------------------------
		   Prise en main de Stata 
	------------------------------------------------------------------

* Raccourcis clavier 	(Sous Windows)

	-----------------
		CTRL+L: Stata sélectionne la ligne sur laquelle est le curseur
	
		CTRL+D : Stata execute la partie du texte selectionne 
	

**********************************************************************************************/
* log using journal , replace text // enregistre tout ce qui apparait dans la fenetre de sortie
* log close

		quietly {                      
			// ne fait pas apparaitre l'outcomes des commandes de la boucle
		clear *						// supprimer tout ce qui se trouve en memoire
		set mem 512m				// augmenter la memoire disponible
		set mat 800					// agmenter le nbr variables (800 = max. sous Stata IC)
		set more off, perma			// ne pas interrompre le deroulement des progr. par -more-
		noi di "{hline}"			// tracer un trait dans la fenetre de sortie

		noi di as res "Aujourd'hui : " c(current_date)  _col(50) "Ouverture de cette session à " c(current_time) // tableaux à 2 colonnes : date et heure pour le journal
		noi di "{hline}"			// tracer un trait dans la fenetre de sortie
				}

**************************
*** START PROGRAM HERE ***
**************************


	* Define paths to files
global chemin C:\Users\edelesalle\Dropbox\Cours IEDES\Evaluation d'impact\data_nc471	/*chemin où se trouve ma base de données*/



***************************************
*** Session 1 : Introduction aux données de panel
***************************************


	* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------
	* Exercice 1 : Format long/wide - et commandes xt
	* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------

	*1 : Charger la base de données "nlswork47.dta"


	*2 : Description de la base de données
		* a/ Décrivez la base de données : variables,  nombre d'observations, unité d'observation
		* b/ Quelles variables varient dans le temps?
		* c/ Quel est le format de cette base?
		* d/ Quels sont les identifiants
	
	*3. Long --> Wide :
	* a/ Passez la base en en format wide. 
	* b/ Commentez.
	
	*4. Données Wide
	* Les données panel ne sont pas toujours organisées de façon à être directement exploitées
	* a/ Ouvrir la base "reshapewage.dta"
	* b/ Observez la structure des donneés. Commentez.
	* c/ Quel est l'identifiant? 
	* d/ Passer cette base en format long. Comment le nombre d'observations a-t-il évolué ? 
	* e/ Effectuer la même procédure à partir de la base "wide.dta"
	
    * 5 : A partir de la base "nlswork471.dta" en format long:
		* a/ Déclarez la structure de panel de vos données
		* b/ Décrivez vos données avec la commande xtdescribe
		* c/ Analysez la décomposiion de la variance pour chaque variable avec la commande xtsum
		* d/ Tabulez la variable msp, south, union et race avec la commande xttab et xtrans
		
	 
	* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------
	* Exercice 2 : Panel cylindrés, non cylindrés
	* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------
	
	/* Les bases suivantes sont-elles cylindrées? Justifiez votre réponse 
	a/ pig (utilisez la commande "webuse" pour obtenir cette base)
	b/ nlswork471.dta */

	
		* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------
	* Exercice 3 : Rappel: régressions linéaires et validité des hypothèses 
	* ---------------------------------------------------------------------------------------------------
	* ---------------------------------------------------------------------------------------------------
	
	*1. Ouvrir la base "nlswork471.dta". 
	
	* a/ On suppose que le salaire individuel dans la base "nlswork471.dta", wage, dépend du niveau d'éducation (grade), du fait d'être syndicalisé (union), de l'éthnicité (race) et de variables inobservables. Comment cette relation s'écrit-elle ?
	* b/ Quelles hypothèses le modèle MCO fait-il ? 
	* d/ Représenter graphiquement la régression pour les individus noirs syndicalisés. L'hypothèse d'homoscédasticité est-elle vérifiée ? 
	* e/ En cas de violation de l'hypothèse d'homoscédasticité, quelle hypothèse alternative peut-on faire? 
	* f/ Comparer les régressions supposant 1.l'homoscédasticité 2. l'hétéroscédasticité des termes d'erreur. Que concluez-vous?
	* g/ Supposons maintenant que le salaire dépend également de l'ancienneté du contrat (tenure). A l'aide de la commande margins, estimer l'effet marginal de tenure? 
	* Dans un second temps, ajouter un terme d'interaction entre l'ancienneté du contrat et le fait d'être syndicalisé. L'effet marginal évolue-t-il?
	
	
